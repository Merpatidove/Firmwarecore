.pio/esp32_generic/FrameworkArduino/USBMSC.cpp.o: \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/USBMSC.cpp \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/USBMSC.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/soc_caps.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/dio_qspi/include/sdkconfig.h
