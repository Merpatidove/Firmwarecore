.pio/esp32_generic/FrameworkArduino/stdlib_noniso.c.o: \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/stdlib_noniso.c \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/stdlib_noniso.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_system/include/esp_system.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_err.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/newlib/platform_include/stdio.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_compiler.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_attr.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_bit_defs.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_idf_version.h
