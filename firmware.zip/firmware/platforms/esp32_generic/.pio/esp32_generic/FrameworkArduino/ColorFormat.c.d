.pio/esp32_generic/FrameworkArduino/ColorFormat.c.o: \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/ColorFormat.c \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/ColorFormat.h
