.pio/esp32_generic/FrameworkArduino/esp32-hal-touch.c.o: \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-touch.c \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/soc_caps.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/dio_qspi/include/sdkconfig.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_idf_version.h
