.pio/esp32_generic/FrameworkArduino/libb64/cdecode.c.o: \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/libb64/cdecode.c \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/libb64/cdecode.h
