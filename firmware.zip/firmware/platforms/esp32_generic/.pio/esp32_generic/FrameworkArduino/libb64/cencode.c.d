.pio/esp32_generic/FrameworkArduino/libb64/cencode.c.o: \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/libb64/cencode.c \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/libb64/cencode.h
