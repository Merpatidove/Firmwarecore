.pio/esp32_generic/FrameworkArduino/StringUtils.cpp.o: \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/StringUtils.cpp \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/StringUtils.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/WString.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/pgmspace.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/newlib/platform_include/ctype.h
