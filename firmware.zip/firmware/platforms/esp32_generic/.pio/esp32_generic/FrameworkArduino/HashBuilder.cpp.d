.pio/esp32_generic/FrameworkArduino/HashBuilder.cpp.o: \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/HashBuilder.cpp \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/HashBuilder.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/WString.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/pgmspace.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/newlib/platform_include/ctype.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/Stream.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/Print.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/newlib/platform_include/stdio.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/WString.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/Printable.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/HEXBuilder.h
