.pio/esp32_generic/FrameworkArduino/firmware_msc_fat.c.o: \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/firmware_msc_fat.c \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/firmware_msc_fat.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/newlib/platform_include/stdio.h
