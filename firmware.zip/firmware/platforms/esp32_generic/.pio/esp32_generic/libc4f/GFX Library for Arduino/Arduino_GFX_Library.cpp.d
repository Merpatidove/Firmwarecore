.pio/esp32_generic/libc4f/GFX\ Library\ for\ Arduino/Arduino_GFX_Library.cpp.o: \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/Arduino_GFX_Library.cpp \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/Arduino_GFX_Library.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/Arduino_DataBus.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/Arduino.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/newlib/platform_include/stdio.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp_arduino_version.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/FreeRTOS.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/config/include/freertos/FreeRTOSConfig.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/config/xtensa/include/freertos/FreeRTOSConfig_arch.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/include/xtensa_config.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/include/xtensa/hal.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/esp32/include/xtensa/config/core.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/include/xtensa/xtensa-versions.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/esp32/include/xtensa/config/core-isa.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/esp32/include/xtensa/config/core-matmap.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/esp32/include/xtensa/config/tie.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/esp32/include/xtensa/config/system.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/include/xtensa_context.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/include/xtensa/corebits.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/include/xtensa/xtruntime-frames.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/projdefs.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/portable.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/deprecated_definitions.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/portable/xtensa/include/freertos/portmacro.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/include/xtensa/xtruntime.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/esp32/include/xtensa/config/specreg.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/include/xtensa/xtruntime-core-state.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/include/xt_instr_macros.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/include/xtensa/xtruntime.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_hw_support/include/spinlock.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_hw_support/include/esp_cpu.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/soc_caps.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/include/xtensa_api.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/include/xt_utils.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/xtensa/esp32/include/xtensa/config/extreg.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_bit_defs.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_attr.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_hw_support/include/esp_intr_alloc.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_err.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_compiler.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_hw_support/include/esp_intr_types.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_system/include/esp_private/crosscore_int.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_macros.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_assert.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_hw_support/include/esp_memory_utils.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/soc.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_assert.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/interrupts.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/register/soc/reg_base.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/newlib/platform_include/esp_newlib.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/heap/include/esp_heap_caps.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/heap/include/multi_heap.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_rom/include/esp_rom_sys.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/reset_reasons.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_system/include/esp_system.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_common/include/esp_idf_version.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/portable/xtensa/include/freertos/portbenchmark.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_timer/include/esp_timer.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_hw_support/include/esp_etm.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/mpu_wrappers.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/esp_additions/include/freertos/idf_additions.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/task.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/list.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/queue.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/task.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/semphr.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/queue.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/stream_buffer.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/message_buffer.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/stream_buffer.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/event_groups.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/freertos/FreeRTOS-Kernel/include/freertos/timers.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp8266-compat.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/register/soc/gpio_reg.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/stdlib_noniso.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/binary.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/extra_attr.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/variants/esp32/pins_arduino.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_hw_support/include/esp_sleep.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/hal/include/hal/touch_sensor_legacy_types.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/hal/include/hal/gpio_types.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/gpio_num.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-log.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_rom/esp32/include/esp32/rom/ets_sys.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/log/include/esp_log.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/log/include/esp_log_config.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/log/include/esp_log_level.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/log/include/esp_log_color.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/log/include/esp_log_buffer.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/log/include/esp_log_timestamp.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/log/include/esp_log_write.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/log/include/esp_log_format.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/log/include/esp_log_args.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/log/include/esp_log_attr.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/log/include/esp_private/log_attr.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-matrix.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/gpio_sig_map.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-uart.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/uart_pins.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/register/soc/io_mux_reg.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/hal/include/hal/uart_types.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/clk_tree_defs.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-gpio.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_driver_gpio/include/driver/gpio.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_rom/include/esp_rom_gpio.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/gpio_pins.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_driver_gpio/include/driver/gpio_etm.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-ldo.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-touch.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-touch-ng.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_driver_touch_sens/include/driver/touch_sens.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_driver_touch_sens/include/driver/touch_sens_types.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/hal/include/hal/touch_sens_types.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_driver_touch_sens/hw_ver1/include/driver/touch_version_types.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-dac.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-adc.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-spi.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-i2c.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-ledc.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/hal/include/hal/ledc_types.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-rmt.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-sigmadelta.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-timer.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_driver_gptimer/include/driver/gptimer_types.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/hal/include/hal/timer_types.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-bt.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-psram.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-rgb-led.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-cpu.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-hosted.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/WCharacter.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/newlib/platform_include/ctype.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/WString.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/pgmspace.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/Stream.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/Print.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/Printable.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/IPAddress.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/lwip/src/include/lwip/ip_addr.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/lwip/src/include/lwip/opt.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/port/include/lwipopts.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/newlib/platform_include/sys/fcntl.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/newlib/platform_include/sys/ioctl.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/newlib/platform_include/sys/poll.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_system/include/esp_task.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_hw_support/include/esp_random.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/port/include/sntp/sntp_get_set_time.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/port/include/sockets_ext.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/port/freertos/include/arch/sys_arch.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/lwip/src/include/lwip/debug.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/lwip/src/include/lwip/arch.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/port/esp32xx/include/arch/cc.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/lwip/src/include/lwip/def.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/lwip/src/include/lwip/ip4_addr.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/lwip/src/include/lwip/ip6_addr.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/lwip/src/include/lwip/def.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/lwip/lwip/src/include/lwip/ip6_zone.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_netif/include/esp_netif_ip_addr.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/Client.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/Server.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/Udp.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/HardwareSerial.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/HWCDC.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/USBCDC.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/Esp.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_partition/include/esp_partition.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_hw_support/include/hal/cpu_hal.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_hw_support/include/hal/cpu_ll.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/freertos_stats.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/io_pin_remap.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/Arduino.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/YCbCr2RGB.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_AVRPAR8.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_UNOPAR8.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/Arduino_DataBus.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_AVRPAR16.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_DUEPAR16.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32DSIPanel.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32LCD8.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32LCD16.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32PAR8.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32PAR8Q.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32PAR8QQ.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32PAR8QQQ.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32PAR16.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32PAR16Q.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32PAR16QQ.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32QSPI.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_driver_spi/include/driver/spi_master.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/hal/esp32/include/hal/spi_types.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/hal/include/hal/spi_types.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_driver_spi/include/driver/spi_common.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_system/include/esp_ipc.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32RGBPanel.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32S2PAR8.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32S2PAR8Q.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32S2PAR16.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32S2PAR16Q.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32SPI.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/register/soc/spi_reg.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/register/soc/spi_struct.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/periph_defs.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_hw_support/port/esp32/include/soc/rtc.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/include/soc/rtc_periph.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/include/soc/rtc_io_periph.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/rtc_io_channel.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/include/soc/rtc_cntl_periph.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/register/soc/rtc_cntl_reg.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/register/soc/rtc_cntl_struct.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/hal/esp32/include/hal/clk_gate_ll.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/hal/platform_port/include/hal/assert.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/register/soc/dport_reg.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/soc/esp32/include/soc/dport_access.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-periman.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_hw_support/include/esp_private/periph_ctrl.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32-libs/esp32/include/esp_rom/esp32/include/esp32/rom/gpio.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP32SPIDMA.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_ESP8266SPI.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_HWSPI.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/libraries/SPI/src/SPI.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-spi.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_mbedSPI.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_NRFXSPI.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_RPiPicoPAR8.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_RPiPicoPAR16.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_RPiPicoSPI.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_RTLPAR8.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_STM32PAR8.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_SWPAR8.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_SWPAR16.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_SWSPI.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_Wire.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/libraries/Wire/src/Wire.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/esp32-hal-log.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/HardwareI2C.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_XL9535SWSPI.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_XCA9554SWSPI.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/Arduino_GFX.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/Arduino_G.h \
 C:/Users/ThinkPad/.platformio/packages/framework-arduinoespressif32/cores/esp32/Print.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/gfxfont.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/canvas/Arduino_Canvas.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/canvas/../Arduino_DataBus.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/canvas/../Arduino_GFX.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/canvas/Arduino_Canvas_Indexed.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/canvas/Arduino_Canvas_3bit.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/canvas/Arduino_Canvas_Mono.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ILI9488_3bit.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ILI9488.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/../Arduino_GFX.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/../Arduino_TFT.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/../Arduino_DataBus.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/../Arduino_GFX.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_AXS15231B.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_CO5300.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/../Arduino_OLED.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_DSI_Display.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/../Arduino_DataBus.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_GC9A01.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/./Arduino_GFX.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_GC9C01.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_GC9D01.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_GC9106.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_GC9107.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_HX8347C.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_HX8347D.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_HX8347G.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_HX8352C.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_HX8357A.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_HX8357B.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_HX8369A.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ILI9225.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ILI9331.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ILI9341.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ILI9342.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ILI9481_18bit.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/../Arduino_TFT_18bit.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/../Arduino_TFT.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ILI9486.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ILI9486_18bit.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ILI9488.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ILI9488_18bit.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ILI9806.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_JBT6K71.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_JD9613.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_NT35310.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_NT35510.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_NT39125.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_NV3001B.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_NV3007.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_NV3023.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_NV3041A.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_OTM8009A.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_R61529.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_RM67162.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_RM690B0.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_RGB_Display.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_SEPS525.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_SH1106.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/../databus/Arduino_Wire.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_SH8601.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_SPD2010.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_SSD1283A.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_SSD1306.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_SSD1331.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_SSD1351.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_SSD1357.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ST7735.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ST7789.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ST77916.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_ST7796.h \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/display/Arduino_WEA2012.h
