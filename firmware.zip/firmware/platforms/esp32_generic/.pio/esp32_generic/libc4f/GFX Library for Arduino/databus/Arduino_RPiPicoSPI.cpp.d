.pio/esp32_generic/libc4f/GFX\ Library\ for\ Arduino/databus/Arduino_RPiPicoSPI.cpp.o: \
 .pio/libdeps/esp32_generic/GFX\ Library\ for\ Arduino/src/databus/Arduino_RPiPicoSPI.cpp
