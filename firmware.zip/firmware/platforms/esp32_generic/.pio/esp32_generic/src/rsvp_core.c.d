.pio/esp32_generic/src/rsvp_core.c.o: src/rsvp_core.c src/rsvp_core.h
